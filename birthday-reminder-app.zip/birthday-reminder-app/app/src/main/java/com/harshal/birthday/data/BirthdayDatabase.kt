package com.harshal.birthday.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Birthday::class], version = 1)
abstract class BirthdayDatabase : RoomDatabase() {
    abstract fun dao(): BirthdayDao

    companion object {
        @Volatile private var INSTANCE: BirthdayDatabase? = null
        fun get(context: Context): BirthdayDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BirthdayDatabase::class.java, "birthday-db"
                ).build().also { INSTANCE = it }
            }
    }
}
