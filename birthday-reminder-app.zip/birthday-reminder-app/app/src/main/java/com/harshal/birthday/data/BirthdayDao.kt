package com.harshal.birthday.data

import androidx.room.*

@Dao
interface BirthdayDao {
    @Query("SELECT * FROM birthdays ORDER BY name ASC")
    suspend fun getAll(): List<Birthday>

    @Insert
    suspend fun insert(b: Birthday): Long

    @Update
    suspend fun update(b: Birthday)

    @Delete
    suspend fun delete(b: Birthday)

    @Query("SELECT * FROM birthdays")
    suspend fun rawAll(): List<Birthday>
}
