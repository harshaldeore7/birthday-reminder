package com.harshal.birthday.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "birthdays")
data class Birthday(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val nickname: String,
    /** Stored as ISO-8601 date "YYYY-MM-DD" */
    val birthdate: String,
    /** Persisted URI string from ACTION_OPEN_DOCUMENT */
    val photoUri: String? = null,
)
