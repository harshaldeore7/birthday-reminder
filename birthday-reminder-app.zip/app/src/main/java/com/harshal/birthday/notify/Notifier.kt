package com.harshal.birthday.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.harshal.birthday.R
import com.harshal.birthday.data.BirthdayDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object Notifier {
    private const val CHANNEL_ID = "birthday_channel"

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = ctx.getString(R.string.channel_name)
            val desc = ctx.getString(R.string.channel_desc)
            val channel = NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = desc
            }
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    fun scheduleDailyCheck(ctx: Context) {
        ensureChannel(ctx)

        // compute initial delay to next 09:00
        val now = LocalTime.now()
        val nine = LocalTime.of(9, 0)
        val delay = if (now.isBefore(nine))
            Duration.between(now, nine)
        else
            Duration.between(now, nine).plusHours(24)

        val req = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay.toMinutes(), TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "birthday-daily-check",
            ExistingPeriodicWorkPolicy.UPDATE,
            req
        )
    }

    fun post(ctx: Context, title: String, body: String, id: Int) {
        ensureChannel(ctx)
        val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_cake_fg)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(ctx)) {
            notify(id, builder.build())
        }
    }
}

class DailyWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val db = BirthdayDatabase.get(ctx)
        val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE).substring(5) // "MM-DD"

        val list = runBlocking(Dispatchers.IO) { db.dao().rawAll() }

        var id = 1000
        list.forEach { b ->
            if (b.birthdate.length >= 10) {
                val mmdd = b.birthdate.substring(5)
                if (mmdd == today) {
                    val nick = if (b.nickname.isBlank()) b.name else b.nickname
                    Notifier.post(ctx, "Birthday Today 🎂", "It's ${b.name}'s birthday. Tap to wish $nick!", id++)
                }
            }
        }
        return Result.success()
    }
}
