package com.harshal.birthday

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import coil.compose.rememberAsyncImagePainter
import com.harshal.birthday.data.Birthday
import com.harshal.birthday.data.BirthdayDatabase
import com.harshal.birthday.notify.Notifier
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Notifier.scheduleDailyCheck(this)

        setContent {
            App()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val db = remember { BirthdayDatabase.get(ctx) }
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<Birthday>()) }
    var showAdd by remember { mutableStateOf(false) }
    var editing: Birthday? by remember { mutableStateOf(null) }

    LaunchedEffect(Unit) {
        list = db.dao().getAll()
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Birthday Reminder") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showAdd = true }) {
                Text("+")
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No birthdays yet. Tap + to add.")
                }
            } else {
                LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                    items(list) { bday ->
                        BirthdayRow(
                            b = bday,
                            onClick = { editing = bday; showAdd = true },
                            onShare = {
                                val nick = bday.nickname.ifBlank { bday.name }
                                val msg = "Happy Birthday $nick 🎉"
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, msg)
                                    type = "text/plain"
                                }
                                try {
                                    sendIntent.setPackage("com.whatsapp")
                                    ctx.startActivity(Intent.createChooser(sendIntent, "Share"))
                                } catch (e: Exception) {
                                    ctx.startActivity(Intent.createChooser(sendIntent, "Share"))
                                }
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddEditDialog(
            initial = editing,
            onDismiss = { showAdd = false },
            onSave = { entity ->
                scope.launch {
                    if (entity.id == 0L) db.dao().insert(entity) else db.dao().update(entity)
                    list = db.dao().getAll()
                    showAdd = false
                }
            },
            onDelete = { entity ->
                scope.launch {
                    if (entity.id != 0L) db.dao().delete(entity)
                    list = db.dao().getAll()
                    showAdd = false
                }
            }
        )
    }
}

@Composable
fun BirthdayRow(b: Birthday, onClick: () -> Unit, onShare: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val painter = rememberAsyncImagePainter(b.photoUri?.let { Uri.parse(it) })
        Image(
            painter = painter,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(b.name, fontWeight = FontWeight.Bold)
            Text("Nickname: ${b.nickname.ifBlank { "-" }}", maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Birthdate: ${b.birthdate}", maxLines = 1)
        }
        TextButton(onClick = onShare) { Text("Share") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditDialog(initial: Birthday?, onDismiss: () -> Unit, onSave: (Birthday) -> Unit, onDelete: (Birthday) -> Unit) {
    val ctx = LocalContext.current
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            photoUri = uri.toString()
        }
    }

    var name by remember { mutableStateOf(initial?.name ?: "") }
    var nickname by remember { mutableStateOf(initial?.nickname ?: "") }
    var birthdate by remember { mutableStateOf(initial?.birthdate ?: LocalDate.now().format(DateTimeFormatter.ISO_DATE)) }
    var photoUri by remember { mutableStateOf(initial?.photoUri ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val id = initial?.id ?: 0L
                onSave(Birthday(id, name.trim(), nickname.trim(), birthdate.trim(), photoUri.ifBlank { null }))
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (initial != null) {
                    TextButton(onClick = { onDelete(initial) }) { Text("Delete") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
        title = { Text(if (initial == null) "Add Birthday" else "Edit Birthday") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(value = nickname, onValueChange = { nickname = it }, label = { Text("Nickname") }, singleLine = true)
                OutlinedTextField(value = birthdate, onValueChange = { birthdate = it }, label = { Text("Birthdate (YYYY-MM-DD)") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { pickImage.launch(arrayOf("image/*")) }) { Text("Pick Photo") }
                    Spacer(Modifier.width(8.dp))
                    if (photoUri.isNotBlank()) {
                        val painter = rememberAsyncImagePainter(Uri.parse(photoUri))
                        Image(painter, contentDescription = null, modifier = Modifier.size(48.dp), contentScale = ContentScale.Crop)
                    } else {
                        Text("No photo selected", modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    )
}
